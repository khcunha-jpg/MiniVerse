const socket = io();
let scene, camera, renderer;
let players = {}, myId = null;
let moveSpeed = 0.1, keys = {};

document.getElementById("btnEnter").onclick = () => {
  const name = document.getElementById("nickname").value.trim();
  const vip = document.getElementById("vip").checked;
  if(!name) return alert("Digite seu nickname!");
  document.getElementById("loginScreen").style.display = "none";
  document.getElementById("hud").style.display = "block";
  socket.emit("newPlayer",{name,vip});
  initScene();
};

function initScene(){
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight,0.1,1000);
  renderer = new THREE.WebGLRenderer({antialias:true});
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);
  const light = new THREE.DirectionalLight(0xffffff,1);
  light.position.set(10,10,10); scene.add(light);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(200,200), new THREE.MeshStandardMaterial({color:0xa0d8a0}));
  ground.rotation.x=-Math.PI/2; scene.add(ground);
  camera.position.set(0,5,10); animate();
}

function animate(){ requestAnimationFrame(animate); handleMovement(); renderer.render(scene,camera); }
function handleMovement(){
  const player = players[myId]; if(!player) return;
  if(keys["w"]) player.position.z -= moveSpeed;
  if(keys["s"]) player.position.z += moveSpeed;
  if(keys["a"]) player.position.x -= moveSpeed;
  if(keys["d"]) player.position.x += moveSpeed;
  socket.emit("move",{x:player.position.x,z:player.position.z});
  camera.lookAt(player.position);
}
window.addEventListener("keydown",(e)=>keys[e.key.toLowerCase()]=true);
window.addEventListener("keyup",(e)=>keys[e.key.toLowerCase()]=false);

socket.on("updatePlayers",(data)=>{
  for(let id in data){
    if(!players[id]){
      const geo=new THREE.BoxGeometry(1,2,1);
      const mat=new THREE.MeshStandardMaterial({color:data[id].vip?0xffd700:0x3366ff});
      const mesh=new THREE.Mesh(geo,mat); mesh.position.y=1; scene.add(mesh);
      players[id]=mesh; if(!myId&&id===socket.id) myId=id;
    }
    players[id].position.x=data[id].x; players[id].position.z=data[id].z;
  }
  for(let id in players){ if(!data[id]){ scene.remove(players[id]); delete players[id]; } }
});

const chatInput=document.getElementById("chatInput");
chatInput.addEventListener("keypress",(e)=>{ if(e.key==="Enter"&&chatInput.value.trim()!==""){ socket.emit("chatMessage",chatInput.value); chatInput.value=""; } });
socket.on("chatMessage",(msg)=>{ const chatBox=document.getElementById("chatBox"); const line=document.createElement("div"); line.innerHTML=`${msg.vip?"⭐ ":""}<b>${msg.name}:</b> ${msg.text}`; chatBox.appendChild(line); chatBox.scrollTop=chatBox.scrollHeight; });