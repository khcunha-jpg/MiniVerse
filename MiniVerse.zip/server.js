const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http);

const PORT = process.env.PORT || 3000;

app.use(express.static("public"));

let players = {};

io.on("connection", (socket) => {
  console.log("Novo jogador conectado:", socket.id);

  socket.on("newPlayer", (data) => {
    players[socket.id] = { id: socket.id, name: data.name, vip: data.vip, x:0, z:0 };
    io.emit("updatePlayers", players);
  });

  socket.on("move", (pos) => {
    if (players[socket.id]) {
      players[socket.id].x = pos.x;
      players[socket.id].z = pos.z;
      io.emit("updatePlayers", players);
    }
  });

  socket.on("chatMessage", (msg) => {
    const player = players[socket.id];
    if (player) io.emit("chatMessage", { name: player.name, vip: player.vip, text: msg });
  });

  socket.on("disconnect", () => {
    delete players[socket.id];
    io.emit("updatePlayers", players);
  });
});

http.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));